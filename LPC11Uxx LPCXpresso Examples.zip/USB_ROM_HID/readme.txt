Purpose:
A program to implement USB Human Interface Device (HID) class using USB ROM drivers on LPC11U2x and above

Note:
Tested on NGX LPC11U24 Board

Running mode:
* Make, Download and Debug
* LPC11Uxx is detected as a HID compliant device (power cycle may be required)

