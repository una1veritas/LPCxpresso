Purpose:
A program to implement USB Mass Strorage class (MSC) device using ROM Drivers on LPC11U2x and above

Note:
This example has been tested on NGX LPC11U24/301 board

Running mode:
* Make, Download and Debug
* LPC11Uxx is detected as a Mass strorage device

