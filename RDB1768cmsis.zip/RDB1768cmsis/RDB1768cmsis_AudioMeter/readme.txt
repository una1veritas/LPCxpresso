Code Red Technologies RDB1768 Board - Audio Level Meter
=======================================================

[ Note that this project requires the relevant CMSIS library 
  project as well as the LCDLib project to exist in the same 
  workspace. ]
  
This demonstration project provides a simple example that uses
the audio facilities provided by the RDB1768. It also makes use
of the LCD screen to display a meter showing levels for the audio
being received. 

To run the example, you will need to connect an audio source,
such as an MP3 player, to the 3.5mm line-in socket of the RDB1768.

The audio signal received can then be redirected to the built-in
speaker of the RDB1768 by moving switch S2-2 (Audio-SP) to the right.

Alternatively, connected a set of headphones or external speakers to
the 3.5mm headphones socket of the RDB1768.

Note
====
The RDB1768cmsis_AudioMeter project contains a routine called
whichRDB(). This allows the code to determine at runtime whether
it is running on an RDB1768 (v1), or RDB1768v2 board. This check
is done by reading a register in the ethernet phy - which differs
between the two boards.

This check is then used to determine which audio codec needs to
be used by the rest of the application.

~~~~~~~~~~~~
Note that this example is only suitable for use with Red Suite / 
LPCXpresso IDE v3.6.x (v3.8.x for Linux) or later, as it makes 
use of linker related functionality introduced in this release.

More details at:

http://support.code-red-tech.com/CodeRedWiki/EnhancedManagedLinkScripts




