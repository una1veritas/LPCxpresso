extern unsigned int cortex128x57_width;
extern unsigned int cortex128x57_height;
extern const unsigned short cortex128x57_pixel_data [];
