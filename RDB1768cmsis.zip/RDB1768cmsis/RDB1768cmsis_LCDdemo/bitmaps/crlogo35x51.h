extern unsigned int crlogo35x51_width;
extern unsigned int crlogo35x51_height;
extern const unsigned short crlogo35x51_pixel_data [];
