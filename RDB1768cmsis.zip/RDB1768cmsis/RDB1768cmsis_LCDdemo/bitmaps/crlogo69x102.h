extern unsigned int crlogo69x102_width;
extern unsigned int crlogo69x102_height;
extern const unsigned short crlogo69x102_pixel_data [];
