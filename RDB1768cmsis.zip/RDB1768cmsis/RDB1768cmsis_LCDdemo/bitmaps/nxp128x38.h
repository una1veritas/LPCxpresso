extern unsigned int nxp128x38_width;
extern unsigned int nxp128x38_height;
extern const unsigned short nxp128x38_pixel_data [];
