Code Red Technologies RDB1768 Board - User Leds Demo
====================================================

[ Note that this project requires the relevant CMSIS library 
  project to exist in the same workspace. ]

This demonstration project show how the user leds, LED_2 to
LED_5, of the RDB1768 be accessed.

The project defines a number of functions to switch the leds
on and off, individually and as a group, and also to invert the
current state of the leds. The demonstration itself then calls
these functions to flash the leds in various combinations.

~~~~~~~~~~~~
Note that this example is only suitable for use with Red Suite / 
LPCXpresso IDE v3.6.x (v3.8.x for Linux) or later, as it makes 
use of linker related functionality introduced in this release.

More details at:

http://support.code-red-tech.com/CodeRedWiki/EnhancedManagedLinkScripts

