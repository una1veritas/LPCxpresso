Code Red Technologies RDB1768 Board - LedStrobe Demo
====================================================

[ Note that this project requires the relevant CMSIS library 
  project to exist in the same workspace. ]

This demonstration project show how the user leds, LED_2 to
LED_5, of the RDB1768 be accessed to provide a strobing effect.

When executed, the code will set up the Systick timer (built into 
the Cortex-M3 CPU) so that a timer tick takes place every 
1/1000th of a second.

The code strobe though LED_2 to LED_5, flashing each on, then 
off in turn. The period of this flash will start off relatively
slowly, get faster, and then slow down.

If you stop the code whilst it is running, you can modify how
fast and slow the flashing gets, and how quickly it changes by
modifying the variables 'maxflashval', 'minflashval' and 
'changeval'.

~~~~~~~~~~~~
Note that this example is only suitable for use with Red Suite / 
LPCXpresso IDE v3.6.x (v3.8.x for Linux) or later, as it makes 
use of linker related functionality introduced in this release.

More details at:

http://support.code-red-tech.com/CodeRedWiki/EnhancedManagedLinkScripts


