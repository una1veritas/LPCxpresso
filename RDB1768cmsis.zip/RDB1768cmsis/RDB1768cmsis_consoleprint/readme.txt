Code Red Technologies RDB1768 Board - consoleprint demo
=======================================================
[ Note that this project requires the relevant CMSIS library 
  project to exist in the same workspace. ]

When creating a new embedded application, it can sometimes be
useful during the early stages of development to be able to 
output debug status messages to indicate what is happening as
your application executes.

Traditionally, this might be done by piping the messages over,
say, a serial cable connected to a terminal program running on
your PC. Code Red's IDE also offers an alternative to this, 
called semihosting. Semihosting provides a mechanism for code 
running on the target board to use the facilities of the PC 
running the IDE. The most common example of this is for the 
strings passed to a printf being displayed in the IDE's console
view.

The way semihosting is actually implemented depends upon what 
target CPU you are running on. With Cortex-M3 and Cortex-M0 
CPUs, as found in the NXP LPC13xx/17xx and the NXP LPC11xx,
the bottom level of the C library contains a special BKPT
instruction. The execution of this is trapped by the debug 
tools which determine what operation is being requested - in
the case of a printf, for example, this will effectively be 
a "write character to stdout". The debug tools will then read
the character from the memory of the target board - and 
display it in the console window within the IDE.

[On ARM7/9 based targets the same principles of working are 
used, but implemented using the SWI / SVC instruction rather 
than the BKPT.]

It is fair to say that the semihosting mechanism does not 
provide a high performance i/o system. Each time a semihosting 
operation takes place, the processor is basically stopped whilst
the data transfer takes place - and for a printf this happens 
once for each character being displayed. The time this takes 
depends somewhat on the target CPU, the debug probe/link, the 
PC hardware and the PC operating system. But it takes a 
definite period of time, which may make your code appear to 
run more slowly.

The consoleprint() function provided as part of this
demonstration project provides a "print string to console" 
function that uses the CodeRed semihosting debug channel 
functionality. Because this can send a full string in one 
operation, rather than a single character (as using printf 
will) this will provide faster prints to the console.

Note that the symbol "CR_INTEGER_PRINTF" is defined by the 
project. This tells the Redlib C library that the none-floating
point version of printf can be linked in, which reduces the
size of the application.

Finally, it is important to realise that using semihosting
functionality makes you application code reliant upon the
debugger being connected to you board - without the debugger
connected, your code will not run.

~~~~~~~~~~~~
Note that this example is only suitable for use with Red Suite / 
LPCXpresso IDE v3.6.x (v3.8.x for Linux) or later, as it makes 
use of linker related functionality introduced in this release.

More details at:

http://support.code-red-tech.com/CodeRedWiki/EnhancedManagedLinkScripts

