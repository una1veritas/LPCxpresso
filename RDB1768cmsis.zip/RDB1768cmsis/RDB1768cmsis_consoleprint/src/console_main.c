//*****************************************************************************
//   +--+
//   | ++----+
//   +-++    |
//     |     |
//   +-+--+  |
//   | +--+--+
//   +----+    Copyright (c) 2010-11 Code Red Technologies Ltd.
//
// console_main.c - demonstrates use of consoleprint() - a "print string to
//                  console" function that uses the CodeRed semihosting
//                  debug channel functionality.
//
// Software License Agreement
//
// The software is owned by Code Red Technologies and/or its suppliers, and is
// protected under applicable copyright laws.  All rights are reserved.  Any
// use in violation of the foregoing restrictions may subject the user to criminal
// sanctions under applicable laws, as well as to civil liability for the breach
// of the terms and conditions of this license.
//
// THIS SOFTWARE IS PROVIDED "AS IS".  NO WARRANTIES, WHETHER EXPRESS, IMPLIED
// OR STATUTORY, INCLUDING, BUT NOT LIMITED TO, IMPLIED WARRANTIES OF
// MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE APPLY TO THIS SOFTWARE.
// USE OF THIS SOFTWARE FOR COMMERCIAL DEVELOPMENT AND/OR EDUCATION IS SUBJECT
// TO A CURRENT END USER LICENSE AGREEMENT (COMMERCIAL OR EDUCATIONAL) WITH
// CODE RED TECHNOLOGIES LTD.
//
//*****************************************************************************

#include <stdio.h>
#include "consoleprint.h"

#include <cr_section_macros.h>
#include <NXP/crp.h>

// Variable to store CRP value in. Will be placed automatically
// by the linker when "Enable Code Read Protect" selected.
// See crp.h header for more information
__CRP const unsigned int CRP_WORD = CRP_NO_CRP ;

/* Define PRINT_NUMBER_LOOP if you want the demonstration to write
 * numbers during the loop iterations
 */
#define PRINT_NUMBER_LOOP

/* Define the number of times you want the demonstration to write to
 * the debugger console
 */
#define ITERATIONS 10

/* Define PRINT_WITH_PRINTF if you want the demonstration to start
 * by writing to the debugger console using printf(), before using
 * consoleprint().
 */
#define PRINT_WITH_PRINTF

#define BUF_SIZE 30
char buffer[BUF_SIZE];	// Character buffer to hold string for consoleprint
					    // Make sure this is big enough !!!

int main(void) {
	
	int loop;


#ifdef PRINT_WITH_PRINTF
	// ************************
	// Start off using printf()
	// ************************
	printf ("printf() demonstration...\n");
	for (loop=0; loop < ITERATIONS; loop++)
	{
#ifdef PRINT_NUMBER_LOOP
		printf ("Loop number : %d\n", loop);
#else
		printf ("printf'ing 10 times\n");
#endif
	}
#endif

	// ***********************
	// Now use consoleprint()
	// ***********************
	consoleprint("consoleprint() demonstration...\n");
	for (loop=0; loop < ITERATIONS; loop++)
	{
#ifdef PRINT_NUMBER_LOOP
		snprintf (buffer,BUF_SIZE, "Loop number : %d\n", loop);
		consoleprint (buffer);
#else
		consoleprint ("consoleprint'ing 10 times\n");
#endif
	}

	consoleprint("Finished, entered infinite loop\n");
	// Enter an infinite loop, just incrementing a counter
	volatile static int i = 0 ;
	while(1) {
		i++ ;
	}
	return 0 ;
}
