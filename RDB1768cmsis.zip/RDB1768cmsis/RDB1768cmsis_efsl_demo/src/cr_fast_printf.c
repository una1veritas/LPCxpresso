//*****************************************************************************
//   +--+
//   | ++----+
//   +-++    |
//     |     |
//   +-+--+  |
//   | +--+--+
//   +----+    Copyright (c) 2010 Code Red Technologies Ltd.
//
// cr_fast_printf.c - provides a replacement 'printf' function - which uses
//                    the consoleprint() routine to write a string out to the
//                    debugger console. As consoleprint() writes the whole
//                    string at a time, rather than each character one at a time,
//                    this will be faster than using the standard printf routine.
//
// Software License Agreement
//
// The software is owned by Code Red Technologies and/or its suppliers, and is
// protected under applicable copyright laws.  All rights are reserved.  Any
// use in violation of the foregoing restrictions may subject the user to criminal
// sanctions under applicable laws, as well as to civil liability for the breach
// of the terms and conditions of this license.
//
// THIS SOFTWARE IS PROVIDED "AS IS".  NO WARRANTIES, WHETHER EXPRESS, IMPLIED
// OR STATUTORY, INCLUDING, BUT NOT LIMITED TO, IMPLIED WARRANTIES OF
// MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE APPLY TO THIS SOFTWARE.
// USE OF THIS SOFTWARE FOR COMMERCIAL DEVELOPMENT AND/OR EDUCATION IS SUBJECT
// TO A CURRENT END USER LICENSE AGREEMENT (COMMERCIAL OR EDUCATIONAL) WITH
// CODE RED TECHNOLOGIES LTD.
//
//*****************************************************************************

#include <stdio.h>
#include <stdarg.h>
#include <stdlib.h>
#include <string.h>
#include "consoleprint.h"

int cr_fast_printf(const char *fmt, ...)
{
    va_list args;
    size_t  len =0;
    char   *space;

    // Allocate small amount of space on heap, and check for error
    if ((space = (char *)malloc(4)) != 0)
    {
    	// Find out how big string to print will be

        va_start(args, fmt);
    	len = vsnprintf(space, 1, fmt, args);
    	va_end(args);
    	free (space);

    	// Now reserve enough actual space for string
        if ((space = (char *)malloc(len + 2)) != 0)
        {
        	va_start(args, fmt);
        	// write the string out to the buffer
        	vsnprintf (space, len+2, fmt,args);
        	va_end(args);
        	// Write string out to console
        	len = consoleprint (space);
        	free(space);
        }
    }
    return len;
}
