Code Red Technologies RDB1768 Board - Timers Demo
=================================================

[ Note that this project requires the relevant CMSIS library 
  project to exist in the same workspace. ]
  
This simple project shows how the 4 timers to be found in the
LPC1768 MCU fitted to the RDB1768 development board, and 
flashes the LEDs based on when the timers trigger interrupts.

Download the project to the board and run it. The state of each
the user leds will toggle based on how the corresponding timer
is set up.

The code to access the LEDs (leds.h and leds.c) is taken from the
RDB1768cmsis_LedFlash project. See that project for more examples of 
how to use this code.

~~~~~~~~~~~~
Note that this example is only suitable for use with Red Suite / 
LPCXpresso IDE v3.6.x (v3.8.x for Linux) or later, as it makes 
use of linker related functionality introduced in this release.

More details at:

http://support.code-red-tech.com/CodeRedWiki/EnhancedManagedLinkScripts




