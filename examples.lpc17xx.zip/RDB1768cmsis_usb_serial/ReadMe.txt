The RDB1768cmsis_usb_serial example is distributed with LPCXpresso. It operates on the LPC17xx
Xpresso board with no changes. RDB1768cmsis_usb_serial depends upon RDB1768cmsis_usbstack
which can also be found in the example project archive distributed with LPCXPresso.

Location of RDB1768cmsis_usb_serial and RDB1768cmsis_usbstack : C:\nxp\lpcxpresso\Examples\LPC1000\LPC17xx
To download LPCXpresso: http://lpcxpresso.code-red-tech.com/LPCXpresso/