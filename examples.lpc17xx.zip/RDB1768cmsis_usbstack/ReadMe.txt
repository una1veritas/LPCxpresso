The RDB1768cmsis_usbstack is included in in the example project archive distributed with
LPCXPresso.

Location of RDB1768cmsis_usbstack and : C:\nxp\lpcxpresso\Examples\LPC1000\LPC17xx
To download LPCXpresso: http://lpcxpresso.code-red-tech.com/LPCXpresso/