/*
 * NXP Semiconductors- 6/12/2010
 */

#define LIB_FLOAT_PRINTF

#include "small_printf_code.h"

